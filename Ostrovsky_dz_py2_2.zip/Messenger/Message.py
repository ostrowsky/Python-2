from datetime import datetime


class Mess:
    messages = []

    def __init__(self, sender, recipient, text):
        if Mess.messages:
            self.id = Mess.messages[-1].id + 1
        else:
            self.id = 1
        self.sender = sender
        self.recipient = recipient
        self.text = text
        self.time = datetime.now()
        Mess.messages.append(self)
        self.recipient.receive_message(self)
