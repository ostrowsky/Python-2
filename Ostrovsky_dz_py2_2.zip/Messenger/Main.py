from User import User
'''
В данной версии реализуется базовый функционал приложения Messenger
(без реализации сетевого взаимодействия)
по созданию объектно-ориентированной модели пользователей и сообщений,
добавлению пользователей к списку контактов,
отправке сообщений и отображения их истории
'''

Alice = User('Alice', '1111111')
Bob = User('Bob', '2222222')
print(Alice)
print(Bob)

Alice.addContact(Bob)
Alice.getContacts()

Bob.getContacts()
Alice.send_message(Bob, "Привет! Добавь меня в свой список контактов")

Bob.addContact(Alice)
Bob.getContacts()
Bob.send_message(Alice, "Ты кто?")
Alice.send_message(Bob, "Я Alice")
Bob.send_message(Alice, "Привет, Alice. Добавил тебя")
Alice.getMessages()